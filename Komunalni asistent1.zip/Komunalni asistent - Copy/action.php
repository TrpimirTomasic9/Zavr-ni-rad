<?php

	include_once("dbc.php");

	$sActionID="";

	if(isset($_GET['action']))
	{
		$sActionID=$_GET['action'];
	}

	switch ($sActionID) 
	{
		case 'dodajTicket':
			// kreiram varijable i pridruzujem im vrijednosti posalane iz dodajnoviticket funkcije
			$sOpis=$_POST['ti_opis'];
			if(isset($_POST['ti_putanja'])){
				$sPutanja=$_POST['ti_putanja'];
			}
			$sStatus=$_POST['status_st_id'];
			$sDatum=$_POST['ti_datum'];
			$sAdresa=$_POST['ti_adresa'];
			$sLatituda=$_POST['ti_latituda'];
			$sLongituda=$_POST['ti_longituda'];

			$last_id_ticket;
			// jednostruka i dvostruka zagrada zbog toga sto u bazu spremam string sa jednostrukim navodnikom a da bih ubacio vrijednost moram zatvorit string ubacit vrijednost i nastavit dalje string,
			// . je isto sto i + za spajanje stringova,a sql je jedan string koji poslje saljem na izvrsavanje u bazu

			try {
				// PDO::__construct() throws a PDOException if the attempt to connect to the requested database fails.
				//$oDbConnector->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "INSERT INTO kasistent_tiketi (ti_opis, status_st_id, ti_datum, ti_adresa, ti_lat, ti_lng ) VALUES ('".$sOpis."', ".$sStatus.", '".$sDatum."', '".$sAdresa."',  ".$sLatituda.",  ".$sLongituda.")";
				$oDbConnector->exec($sql);
				$last_id_ticket = $oDbConnector->lastInsertId();
				echo $last_id_ticket;
			} catch(PDOException $e) {
				echo $sql . "<br>" . $e->getMessage();
			}
			// provjerava da li je unesena neka slika
			// ak nije unesena nista ak je ide u foreach za svaku sliku i ubacuje u bazu kasistent_images
			if(isset($sPutanja)){
				foreach ($sPutanja as $image){
					try {
						$oDbConnector->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql = "INSERT INTO kasistent_images (id, image) VALUES ('".$last_id_ticket."', '".$image."')";
						$oDbConnector->exec($sql);
					} catch(PDOException $e) {
						echo $sql . "<br>" . $e->getMessage();
					}
				}
			}

			$oDbConnector = null;

		break;

		case 'pronadiTicket':

			$oJson = array();

			$sCode=$_POST['ti_code'];
			// preso sQuery dohvatim ticket s tim kodom i onda ga spremim u json format i posaljem ga nazad
			try {
				$oDbConnector->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				// kreiranje querija
				$sQuery = "SELECT [ti_id], [ti_opis], [ti_lat], [ti_lng], [status_st_id], FORMAT(ti_datum, 'dd.MM.yyyy') as [ti_datum], [ti_adresa] FROM kasistent_tiketi WHERE ti_id=".$sCode;
				// poziv na bazu s tim quriem
				$oRecord = $oDbConnector ->query($sQuery);
				$oQueryData = $oRecord->fetchAll(PDO::FETCH_ASSOC);
				// dodaje vrijednosti iz redova uzima key value vrijednosti za svaki red koji je dohvacen kreira objekt otemp i doda ga u array Ojesan i na kraju kad izvrti za svaki red pretvori ga u json format i vrati natrag
				foreach ($oQueryData as $oRow)
				{
					$oTmp['Ti_id'] = $oRow['ti_id'];
					$oTmp['Ti_opis'] = $oRow['ti_opis'];
					$oTmp['Ti_lat'] = $oRow['ti_lat'];
					$oTmp['Ti_lng'] = $oRow['ti_lng'];
					$oTmp['Status_st_id'] = $oRow['status_st_id'];
					$oTmp['Ti_datum'] = $oRow['ti_datum'];
					$oTmp['Ti_adresa'] = $oRow['ti_adresa'];

					array_push($oJson, $oTmp);
				}

				$oJson = json_encode($oJson);  
				echo $oJson;

			} catch(PDOException $e) {
				echo $sql . "<br>" . $e->getMessage();
			}

		break;

		case 'dohvatiStatuse':

			$oJson = array();
			try {
				$oDbConnector->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sQuery = "SELECT [st_id], [st_naziv] FROM kasistent_statusi";
				$oRecord = $oDbConnector ->query($sQuery);
				$oQueryData = $oRecord->fetchAll(PDO::FETCH_ASSOC);
		
				foreach ($oQueryData as $oRow)
				{
					$oTmp['St_id'] = $oRow['st_id'];
					$oTmp['St_naziv'] = $oRow['st_naziv'];

					array_push($oJson, $oTmp);
				}

				$oJson = json_encode($oJson);  
				echo $oJson;

			} catch(PDOException $e) {
				echo $sql . "<br>" . $e->getMessage();
			}

		break;

		case 'dohvatiSlike':

			$oJson = array();

			$sCode=$_POST['ti_code'];
			try {
				$oDbConnector->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sQuery = "SELECT [id], [image] FROM kasistent_images WHERE id=".$sCode;

				$oRecord = $oDbConnector ->query($sQuery);
				$oQueryData = $oRecord->fetchAll(PDO::FETCH_ASSOC);
		
				foreach ($oQueryData as $oRow)
				{
					$oTmp['Id'] = $oRow['id'];
					$oTmp['Image'] = $oRow['image'];

					array_push($oJson, $oTmp);
				}

				$oJson = json_encode($oJson);  
				echo $oJson;

			} catch(PDOException $e) {
				echo $sql . "<br>" . $e->getMessage();
			}

		break;
	}

?>