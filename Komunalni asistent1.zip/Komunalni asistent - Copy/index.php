<?php
include_once("dbc.php");
?>

<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Komunalni asistent</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href="assets/plugins/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" />
        <link href="assets/plugins/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
        <link href="assets/plugins/bootstrap/3.3.7/css/bootstrap-theme.min.css" rel="stylesheet" />
        <link href="assets/plugins/bootstrap-eonasdan-datetimepicker/build/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
    
        <style>
            .form-groupT {
                display: flex;
                font-size: 24px;
                border-bottom: 1px solid lightgray;
            }
            p.title {
                margin-right: 10px;
                font-weight: 700;
            }
        </style>
    </head>

    <body style="height: 100vh;width: 100vw; background-image: url('./img/background.jpg');">
        <div class="row" style="
        height: 100%;
        width: 100%;
        margin: 0 !important;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        ">
            <h1 style="
                font-size: 90px;
                font-family: 'Glyphicons Halflings';
                word-spacing: -40px;
                text-shadow: 5px 2px 12px #337ab7;
                margin-top: -200px;
                color: #222;
                font-weight: 600;
            ">Dodaj ticket
            </h1>
            <button class="btn btn-lg" type="button" data-toggle="modal" data-target="#modalDodajTicket" style="
                    margin-top: 40px;
                    color: #222;
                    width: 60px;
                    padding: 0;
                    font-size: 35px;
                    height: 60px;
                    box-shadow: 0px 0px 15px #222;
                    background-color: #337ab7;
            ">+</button>

            <div style="margin-top: 70px; height: 50px;">
                <h1 style="
                    font-size: 90px;
                    font-family: 'Glyphicons Halflings';
                    word-spacing: -40px;
                    text-shadow: 5px 2px 12px #337ab7;
                    color: #222;
                    font-weight: 600;
                ">Provjerite status ticketa
                </h1>
                <input id="input_search_code" class="form-control form-control-lg" type="text" placeholder="Ticket code" style="width: 400px; height: 50px; margin: auto; margin-top: 50px;">
            </div>
        </div>

        <!--MODAL ADD TICKET-->
        <div class="modal fade" id="modalDodajTicket" role="dialog">
            <div class="modal-dialog" style="width: 60vw;">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h4 class="modal-title" style="font-family:'Times New Roman', serif;">Dodaj novi ticket</h4>
                    </div>
                    <div class="modal-body">
                        <div>
                            <div class="row" style="display: flex;flex-direction: row;">
                                <div class="container" style="width: 50%;">
                                    <div class="form-group">        
                                        <label for="DodajOpis" style="font-family:'Times New Roman', serif;">Dodaj opis</label>
                                        <input type="text" style="font-family:'Times New Roman', serif;" class="form-control" id="DodajOpis" placeholder="Dodaj opis ticketa">
                                    </div>
                                    <!--
                                    <div class="form-group">
                                        <label for="DodajStatus" style="font-family:'Times New Roman', serif;">Status</label>
                                        <select id="DodajStatus" class="form-control" style="width: 100%;">
                                            <option value="-1">Izaberite status</option>
                                        </select>
                                        <br /> 
                                    </div>
                                    -->
                                    <div class="form-group">
                                        <label for="DodajSliku" style="font-family:'Times New Roman', serif;">Odaberi sliku</label>
                                        <input type="file" multiple class="form-control" id="DodajSliku" placeholder="Kliknite kako bi ste dodali sliku">
                                    </div>

                                    <div class="form-group">
                                        <label for="datetimepickerAdd">Datum</label>
                                        <div class='input-group date' id='datetimepickerAdd'>
                                            <input type='text' class="form-control" />
                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="DodajAdresa" style="font-family:'Times New Roman', serif;">Adresa lokacije</label>
                                        <input id="DodajAdresa" class="form-control" type="text" placeholder="Upišite adresu lokacije ili će se automatski dodati odabirom lokacije na mapi">
                                    </div>

                                    <div class="form-group">
                                        <label for="DodajLatitudu" style="font-family:'Times New Roman', serif;">Latituda</label>
                                        <input type="number" class="form-control" id="DodajLatitudu" style="font-family:'Times New Roman', serif;" placeholder="Automatsko dodavanje odabirom lokacije na mapi">
                                    </div>
                                    <div class="form-group">
                                        <label for="DodajLongitudu" style="font-family:'Times New Roman', serif;">Longituda</label>
                                        <input type="number" class="form-control" id="DodajLongitudu" style="font-family:'Times New Roman', serif;" placeholder="Automatsko dodavanje odabirom lokacije na mapi">
                                    </div>
                                </div>
                                <div  class="container" style="width: 50%;">
                                    <div class="row" style="height: 100%;">
                                        <div class="col-md-12 modal_body_map" style="height: 100%;">
                                            <div class="location-map" id="location-map" style="height: 100%;">
                                                <div id="map_canvas" style="width: 100%; height: 100%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" style="font-family:'Times New Roman', serif;" onclick="ZatvoriTicket()">Zatvori</button>
                        <button type="button" class="btn btn-primary" style="font-family:'Times New Roman', serif;" onclick="DodajNoviTicket()">Dodaj Ticket</button>
                    </div>
                </div>
            </div>
        </div>

        <!--MODAL BROJ TICKETA-->
        <div class="modal fade" id="modalBrojTicketa" role="dialog">
            <div class="modal-dialog" style="width: 30vw;">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">x</span>
                            <span class="sr-only">Zatvori</span>
                        </button>
                        <h4 class="modal-title" style="font-family:'Times New Roman', serif;">Broj ticketa</h4>
                    </div>
                    <div class="modal-body">
                        <div>
                            <div class="row">
                                <h1 class="inner text-center">ID vašeg ticketa je: </h1>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" style="font-family:'Times New Roman', serif;">Zatvori</button>
                    </div>
                </div>
            </div>
        </div>

        <!--MODAL OTVORI TICKET-->
        <div class="modal fade" id="modalTicketa" role="dialog">
            <div class="modal-dialog" style="width: 60vw;">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">x</span>
                            <span class="sr-only">Zatvori</span>
                        </button>
                        <h4 class="modal-title" style="font-family:'Times New Roman', serif;">Ticket</h4>
                    </div>
                    <div class="modal-body">

                        <h1 class="no_match">Nema rezultata za traženi code!</h1>

                        <div class="ticket_info">
                            <div class="row" style="display: flex;flex-direction: row;min-height: 50vh;">
                                <div class="container" style="width: 50%;">

                                    <div class="form-group form-groupT">
                                        <p class="title">Opis: </p>
                                        <p id="opis"></p>
                                    </div>

                                    <div class="form-group form-groupT">
                                        <p class="title">Datum: </p>
                                        <p id="datum"></p>
                                    </div>

                                    <div class="form-group form-groupT">
                                        <p class="title">Adresa: </p>
                                        <p id="adresa"></p>
                                    </div>

                                    <div class="form-group form-groupT">
                                        <p class="title">Latituda: </p>
                                        <p id="lat"></p>
                                    </div>

                                    <div class="form-group form-groupT">
                                        <p class="title">Longituda: </p>
                                        <p id="lng"></p>
                                    </div>

                                    <div class="form-group form-groupT">
                                        <p class="title">Status: </p>
                                        <p id="status"></p>
                                    </div>
                                    
                                </div>
                                <div  class="container" style="width: 50%;">
                                    <div class="row" style="height: 100%;">
                                        <div class="col-md-12 modal_body_map" style="height: 100%;">
                                            <div class="location-map" id="location-map" style="height: 100%;">
                                                <div id="map_canvasT" style="width: 100%; height: 100%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row" id="slikee" style="margin: 0px 10px;">
                                <h1 style="margin: 0;">Slike: </h1>
                            </div>
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" style="font-family:'Times New Roman', serif;">Zatvori</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="assets/plugins/jquery/jquery-3.2.1.min.js"></script>
        <script src="js/funkcije.js"></script>
        <script src="assets/plugins/jquery-ui/jquery-ui.min.js"></script>
        <script src="assets/plugins/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="assets/plugins/bootstrap-daterangepicker/moment.js"></script>
        <script src="assets/plugins/moment/moment-with-locales.min.js"></script>
        <script src="assets/plugins/bootstrap-eonasdan-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
        <script src="assets/plugins/moment/moment.min.js"></script>
        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBohdMi8CRkfc2TR04AixMykRpil3_G1qg&callback&callback=inicijalizacija_googlemaps&libraries=places&v=weekly"></script>

    </body>
</html>
