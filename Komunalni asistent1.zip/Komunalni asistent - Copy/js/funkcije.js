
statusiLista = [];

$(document).ready(function () {
  InitializeDateTimePicker();
  DohvatiStatuse();
  //PopuniDropdownStatusi();

});

function InitializeDateTimePicker() {
  $('#datetimepickerAdd').datetimepicker({
    format: 'DD.MM.YYYY',
    locale: 'hr',
    useCurrent: false,
    defaultDate: moment()
  });
}

//---Inicijalizacija guides---Google Maps https://developers.google.com/maps/documentation/javascript/overview?fbclid=IwAR2GwumydqKlw9D3IOTYMqru7atyoMoQVSIea80XiwW5Az9jwx2Dks6C_7U---
//---Inicijalizacija samples---https://developers.google.com/maps/documentation/javascript/examples/geocoding-simple---
//---Dragend i click---http://jsfiddle.net/87v0obb4/1/---

function inicijalizacija_googlemaps() {

  var marker;

  var myLatlng = { lat: 45.5409, lng: 18.0529 }

  var AdressaElement = document.getElementById("DodajAdresa");

  var map = new google.maps.Map(document.getElementById('map_canvas'),
    {
      zoom: 10,
      center: myLatlng,
    });


  marker = new google.maps.Marker({
    draggable: true,
    position: myLatlng,
    map: map
  });

  google.maps.event.addListener(marker, 'dragend', function (event) {

    var address;
    var geocoder = new google.maps.Geocoder();
    //Geocoding is the process of converting addresses 
    //(like "1600 Amphitheatre Parkway, Mountain View, CA") 
    //into geographic coordinates (like latitude 37.423021 and longitude -122.083739), 
    //which you can use to place markers or position the map.
    //geocode(request, callback)
    geocoder.geocode({ latLng: event.latLng }, function (result, status) {
      if ('OK' === status) {
        console.log(result[0]);
        address = result[0].formatted_address;
        console.log(address);
        AdressaElement.value = address;
      }
      else {
        console.log('Geocode was not successful for the following reason: ' + status);
      }
    });

    document.getElementById("DodajLatitudu").value = event.latLng.lat();
    document.getElementById("DodajLongitudu").value = event.latLng.lng();
  });

  google.maps.event.addListener(map, 'click', function (event) {

    var address;
    var geocoder = new google.maps.Geocoder();
    //Geocoding is the process of converting addresses 
    //(like "1600 Amphitheatre Parkway, Mountain View, CA") 
    //into geographic coordinates (like latitude 37.423021 and longitude -122.083739), 
    //which you can use to place markers or position the map.
    //geocode(request, callback)
    geocoder.geocode({ latLng: event.latLng }, function (result, status) {
      if ('OK' === status) {
        console.log(result[0]);
        address = result[0].formatted_address;
        console.log(address);
        AdressaElement.value = address;
      }
      else {
        console.log('Geocode was not successful for the following reason: ' + status);
      }
    });
    document.getElementById("DodajLatitudu").value = event.latLng.lat();
    document.getElementById("DodajLongitudu").value = event.latLng.lng();
    marker.setPosition(event.latLng);
  });

}
/*
function PopuniDropdownStatusi() {

  $.ajax({
      type: "GET",
      url: 'json.php?action=popuni_dropdown_status_ticketa',
      success: function (oData){

          console.log(oData);

          oData.forEach(function(status)
          {
              var option = document.createElement("option");
              option.value= status.idStatusa;
              option.innerHTML = status.nazivStatusa;

              $('#DodajStatus').append(option);
          }); 
      },
      error: function() {
          console.log('Cannot retrieve data.');
      }
  });
}
*/

//https://stackoverflow.com/questions/1593225/how-to-select-multiple-files-with-input-type-file
var Images;

$('#DodajSliku').on('change', function () {
  _readFileDataUrl(this, function (err, files) {
    if (err) { return }
    Images = files;
    console.log(files)//contains base64 encoded string array holding the image data 
  });
});

var _readFileDataUrl = function (input, callback) {
  var len = input.files.length, _files = [], res = [];
  var readFile = function (filePos) {
    if (!filePos) {
      callback(false, res);
    } else {
      var reader = new FileReader();
      reader.onload = function (e) {
        res.push(e.target.result);
        readFile(_files.shift());
      };
      reader.readAsDataURL(filePos);
    }
  };
  for (var x = 0; x < len; x++) {
    _files.push(input.files[x]);
  }
  readFile(_files.shift());
};
// https://stackoverflow.com/questions/13183630/how-to-open-a-bootstrap-modal-window-using-jquery
function DodajNoviTicket() {

  var Opis = $('#DodajOpis').val();
  var Slike = Images;
  var Status = 2;
  var Datum = $('#datetimepickerAdd').data("DateTimePicker").date().format('YYYY-MM-DD');
  var Adresa = $('#DodajAdresa').val();
  var Latituda = $('#DodajLatitudu').val();
  var Longituda = $('#DodajLongitudu').val();

  if (Opis == "" || Datum == "" || Adresa == "" || Latituda == "" || Longituda == "") {
    alert("Niste ispunili sva polja!");
  }
  else {
    // da isprazni ako ima nesto
    $(".inner").html("");
    $(".inner").append("ID vašeg ticketa je: ");

    var tiket = {
      opis: Opis,
      slika: Slike,
      status: Status,
      datum_prijave: Datum,
      adresa: Adresa,
      latituda: Latituda,
      longituda: Longituda
    };
    console.log(tiket);

    $.ajax({
      type: "POST",
      url: 'action.php?action=dodajTicket',
      data:

      {
        ti_opis: tiket.opis,
        ti_putanja: tiket.slika,
        status_st_id: tiket.status,
        ti_datum: tiket.datum_prijave,
        ti_adresa: tiket.adresa,
        ti_latituda: tiket.latituda,
        ti_longituda: tiket.longituda
      },
      success: function (oData) {
        console.log("OVO ISPISUJE: " + oData);
        console.log("VALJA");
        // hidea modal dodaj ticket
        $('#modalDodajTicket').modal('hide');
        // ispisuje id dodanog ticketa
        $(".inner").append("<p>" + oData + "</p>");
        // pokazuje modal i id dodanog ticketa
        $('#modalBrojTicketa').modal('show');
        $('#DodajOpis').val('');
        $('#DodajSliku').val('');
        $('#DodajAdresa').val('');
        $('#DodajLatitudu').val('');
        $('#DodajLongitudu').val('');
      },
      error: function (XMLHttpRequest, textStatus, exception) {
        console.log("Ajax failure\n");
      },
      async: true
    });
  }

}

// na enter se poziva funkcija pronadi ticket
$('#input_search_code').keypress(function (e) {
  var key = e.which;
  if (key == 13)  // the enter key code
  {
    PronadiTicket();
  }
});

function PronadiTicket() {
  // kreiram varijablu code i pridruzujem joj vrijednost iz inputa
  var Code = $('#input_search_code').val();
  // ukoliko je poslje prazno izbacuje se alert
  if (Code == "") {
    alert("Polje ne smije biti prazno!");
  }
  // ukoliko nije prazno otvara se modal
  else {
    $('#modalTicketa').modal('show');

    $.ajax({
      type: "POST",
      url: 'action.php?action=pronadiTicket',
      data: {
        ti_code: Code
      },
      //parsiram iz json u normalnan objekt a u phpu u json
      success: function (oData) {
        var object;
        data = JSON.parse(oData);
        data.forEach(function (ticket) {

          // [ti_id], [ti_opis], [ti_lat], [ti_lng], [status_st_id], [ti_datum], [ti_adresa]
          object = {
            id: ticket.Ti_id,
            opis: ticket.Ti_opis,
            lat: ticket.Ti_lat,
            lng: ticket.Ti_lng,
            status: ticket.Status_st_id,
            datum: ticket.Ti_datum,
            adresa: ticket.Ti_adresa
          };

          //console.log("ISPIS: " + object.opis);
        });

        // ako je prazno opt ce pisati dvije prazne zagrade
        if (oData === undefined || oData.length == 2) {
          $(".no_match").show();
          $(".ticket_info").hide();
        }
        else {
          $(".no_match").hide();
          $(".ticket_info").show();

          $("#opis").html("");
          $("#opis").append(
            object.opis
          );
          $("#datum").html("");
          $("#datum").append(
            object.datum
          );
          $("#adresa").html("");
          $("#adresa").append(
            object.adresa
          );
          $("#lat").html("");
          $("#lat").append(
            Math.round(object.lat * 10000) / 10000
          );
          $("#lng").html("");
          $("#lng").append(
            Math.round(object.lng * 10000) / 10000
          );

          $("#status").html("");
          $("#status").append(
            statusiLista[object.status - 1].naziv
          );

          if (object.status == 1) {
            $("#status").append(
              '<span style=" height: 25px;width: 25px;background-color: green;border-radius: 50%;display: inline-block;margin-left: 10px;"></span>'
            );
          }
          else if (object.status == 2) {
            $("#status").append(
              '<span style=" height: 25px;width: 25px;background-color: yellow;border-radius: 50%;display: inline-block;margin-left: 10px;"></span>'
            );
          }
          else if (object.status == 3) {
            $("#status").append(
              '<span style=" height: 25px;width: 25px;background-color: red;border-radius: 50%;display: inline-block;margin-left: 10px;"></span>'
            );
          }

          DohvatiSlike(Code);

          var myLatlng = { lat: Number(object.lat), lng: Number(object.lng) }
          var map = new google.maps.Map(document.getElementById('map_canvasT'),
            {
              zoom: 10,
              center: myLatlng,
            });

          marker = new google.maps.Marker({
            position: myLatlng,
            map: map
          });

        }

      },
      error: function (XMLHttpRequest, textStatus, exception) {
        console.log("Ajax failure\n");
      },
      async: true
    });
  }
}

function DohvatiStatuse() {
  $.ajax({
    type: "POST",
    url: 'action.php?action=dohvatiStatuse',
    success: function (oData) {
      var object;
      data = JSON.parse(oData);
      data.forEach(function (status) {
        object = {
          id: status.St_id,
          naziv: status.St_naziv
        };
        statusiLista.push(object);
      });
      return statusiLista;
    },
    error: function (XMLHttpRequest, textStatus, exception) {
      console.log("Ajax failure\n");
    },
    async: true
  });
}

function DohvatiSlike(Code) {
  console.log("Code: " + Code);

  $("#slikee").html("");
  $("#slikee").append('<h1 style="margin: 0;">Slike: </h1>');

  $.ajax({
    type: "POST",
    url: 'action.php?action=dohvatiSlike',
    data: {
      ti_code: Code
    },
    success: function (oData) {
      var object;
      data = JSON.parse(oData);
      if (data.length == 0) {
        $("#slikee").append(
          '<h1 style="margin-left: 20px;font-size: 26px;">Nema unesenih slika..</h1>'
        );
      }
      else {
        data.forEach(function (slika) {
          object = {
            id: slika.Id,
            image: slika.Image
          };

          $("#slikee").append(
            '<img style="height: 200px; width: 300px; margin: 10px;" src="' + object.image + '" />'
          );

        });
      }
    },
    error: function (XMLHttpRequest, textStatus, exception) {
      console.log("Ajax failure\n");
    },
    async: true
  });
}
function ZatvoriTicket() {
  $('#modalDodajTicket').modal('hide');
  $('#DodajOpis').val('');
  $('#DodajSliku').val('');
  $('#DodajAdresa').val('');
  $('#DodajLatitudu').val('');
  $('#DodajLongitudu').val('');
}